<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<META NAME="Search Engines" CONTENT="www.google.com, www.google.co.uk, www.altaVista.com, www.aol.com, www.infoseek.com, www.excite.com, www.hotbot.com, www.lycos.com, www.magellan.com, www.cnet.com, www.voila.com, www.google.fr, www.yahoo.fr, www.yahoo.com, www.alltheweb.com, www.msn.com, www.netscape.com, www.nomade.com">
<META NAME="ROBOTS" CONTENT= "INDEX, FOLLOW">
<META NAME="author" CONTENT= "Ngữ Á Châu">
<META NAME="distribution" content= "global">

	<link rel="shortcut icon" href="Hinh/copy.ico">

<title>Thanh Huong</title>
<script type="text/javascript" src="fckeditor/fckeditor.js"></script>
<style type="text/css">
<!--
body,td,th {
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
.style3 {color: #FF0000; font-weight: bold; }
.doichu
 {
    color:#0000FF;
	text-decoration:none;
 }
 A:hover{color:#00FF66}
-->
</style>
<script type="text/javascript" src="tinymce/jscripts/tiny_mce/tiny_mce.js"></script>
<script type="text/javascript" src="tinymce/text.js"></script>
<script type="text/javascript">
 function checkInput()
  {
    var isOk = true;
   // if(document.tt_mh.txt_masp.value=="")
	 //{
	 //  alert("Hãy nhập mã sản phẩm");
	  // isOk = false;
	// }
	 if(document.tt_mh.txt_tensp.value=="")
	 {
	   alert("Hãy nhập tên sản phẩm");
	   isOk = false;
	 }
	if(document.tt_mh.txt_hinhanh.value=="")
	 {
	   alert("Hãy nhập thông tin hình ảnh sản phẩm");
	   isOk = false;
	 }
	if(document.tt_mh.txt_giaban.value=="")
	 {
	   alert("Hãy nhập giá bán của sản phẩm");
	   isOk = false;
	 }
 return isOk;
  }
</script>
</head>
<body>
<table width="61%" height="530" border="1" bordercolor="#0000FF" style="border-collapse:collapse">
  
  <tr>
    <td width="206" height="22"><div align="center"><strong>Thông Báo </strong></div></td>
    <td width="202"><div align="center"><strong>Hướng Dẫn </strong></div></td>
  </tr>
  <tr>
    <td height="112"  valign="top">
	
	
	<?php
  if(isset($_POST['luu']))
   {
    $today2 = date("D") ;
	$today = date("d") ;
	$today1 = date("m") ;
	$today3 = date("Y") ;
	
		$chuoi= " $today/$today1/$today3 ";
     include_once('database.php');
	   $id=$_REQUEST["id"];
	     $tentaptin =  $_FILES['txt_hinhanh']['name'];
	  if($tentaptin=="")
		{
			$tentaptin=$_POST['txt_hinhanh_hide'];
			
		}
		
	
	 $khuyenmai = $_POST['khuyenmai'];
	 $trangthai = $_POST['trangthai'];
	 $loai=$_POST['thuocloai'];
	 $trangchu = $_POST['trangchu'];
	 $mota = $_POST['mota'];
	 $mota_en = $_POST['mota_en'];
	 
	 	 $noidung= str_replace("'","",$_POST['txt_noidung']);
	 $noidung_en = str_replace("'","",$_POST['txt_noidung_en']);
	 $tieude = str_replace("'","",$_POST['tieude']);
	 $tieude_en = str_replace("'","",$_POST['tieude_en']);
     $masanpham = str_replace("'","",$_POST['masanpham']);
	 $trangthai_en = str_replace("'","",$_POST['trangthai_en']);

	
		  $noidung_china = str_replace("'","",$_POST['txt_noidung_china']);
	 $tieude_china = str_replace("'","",$_POST['tieude_china']);
	$mota_china = str_replace("'","",$_POST['mota_china']);
	$trangthai_china = str_replace("'","",$_POST['trangthai_china']);
	
	 $noidung_han = str_replace("'","",$_POST['txt_noidung_han']);
	 $tieude_han = str_replace("'","",$_POST['tieude_han']);
	$mota_han = str_replace("'","",$_POST['mota_han']);
	$trangthai_han = str_replace("'","",$_POST['trangthai_han']);
	
	$noidung_nhat = str_replace("'","",$_POST['txt_noidung_nhat']);
	 $tieude_nhat = str_replace("'","",$_POST['tieude_nhat']);
	$mota_nhat = str_replace("'","",$_POST['mota_nhat']);
	$trangthai_nhat = str_replace("'","",$_POST['trangthai_nhat']);
	
	$noidung_nga = str_replace("'","",$_POST['txt_noidung_nga']);
	$noidung_my = str_replace("'","",$_POST['txt_noidung_my']);
	$noidung_anh = str_replace("'","",$_POST['txt_noidung_anh']);
	$noidung_phap = str_replace("'","",$_POST['txt_noidung_phap']);
	
	
	
     upload($noidung,  $tentaptin, $tieude, $mota,  $chuoi,$loai, $trangchu , $id, $noidung_en,   $tieude_en, $mota_en, $masanpham, $khuyenmai, $trangthai, $trangthai_en, $noidung_china, $tieude_china, $mota_china, $trangthai_china, $noidung_han, $trangthai_han, $mota_han, $tieude_han, $noidung_nhat, $trangthai_nhat, $mota_nhat, $tieude_nhat, $noidung_nga, $noidung_my, $noidung_anh, $noidung_phap );
	 
	
   
   }
   
function upload($noidung,  $tentaptin, $tieude, $mota,  $chuoi,$loai, $trangchu , $id, $noidung_en,   $tieude_en, $mota_en, $masanpham, $khuyenmai, $trangthai, $trangthai_en, $noidung_china, $tieude_china, $mota_china, $trangthai_china, $noidung_han, $trangthai_han, $mota_han, $tieude_han, $noidung_nhat, $trangthai_nhat, $mota_nhat, $tieude_nhat, $noidung_nga, $noidung_my, $noidung_anh, $noidung_phap)
 {
   $ketnoi_maychu = ketnoi_MC();
	chon_CSDL($ketnoi_maychu);
   $truyvan = "update  ma_sanpham set noidung='$noidung',  hinhanh='$tentaptin', tieude='$tieude', mota='$mota',  ngay='$chuoi',thuocloai='$loai', trangchu='$trangchu', noidung_en='$noidung_en',  tieude_en='$tieude_en', mota_en='$mota_en', masanpham='$masanpham', trangthai='$trangthai', trangthai_en='$trangthai_en', khuyenmai='$khuyenmai', noidung_china='$noidung_china', tieude_china='$tieude_china', mota_china='$mota_china', noidung_han='$noidung_han', trangthai_han='$trangthai_han', trangthai_china='$trangthai_china',  mota_han='$mota_han', noidung_nhat='$noidung_nhat', trangthai_nhat='$trangthai_nhat', mota_nhat='$mota_nhat', tieude_nhat='$tieude_nhat', noidung_nga='$noidung_nga', noidung_my='$noidung_my', noidung_anh='$noidung_anh', noidung_phap='$noidung_phap' where id='$id'";

   $ketqua_truyvan = truyvan($truyvan,$ketnoi_maychu);
   if($ketqua_truyvan)
    dichuyen_taptin_vaothumuc($tentaptin);
   else
    echo "Upload không thành công.Bạn thử lại xem";
	
  mysql_close($ketnoi_maychu);
 }
 
function dichuyen_taptin_vaothumuc($tentaptin)
 {
   $thumuctam_chuataptin = $_FILES['txt_hinhanh']['tmp_name'];
   if(move_uploaded_file($thumuctam_chuataptin,"../Hinh CTSP/$tentaptin"))
   {
      echo "Chúc mừng bạn Upload thành công thông tin";
	
	 
	  }
	else
    {
      xoataptin($tentaptin);
	    echo "Chúc mừng bạn Upload thành công thông tin";
	}
 }
 
function xoataptin($tentaptin)
 {
   $ketnoi_maychu = ketnoi_MC();
	chon_CSDL($ketnoi_maychu);
	$masotaptin = mysql_insert_id();
	$truyvan = "DELETE FROM maykhoanda WHERE id = $masotaptin ";
	$ketqua_truyvan = truyvan($truyvan,$ketnoi_maychu);
 }
?>
</td>
    <td valign="top" align="left"><p><span class="style3">1.</span> <em><strong>Hình ảnh phải nhập đúng kích cở (300x400) hoặc hình lớn hơn một ít, tránh tình trạng nhập vào hình có kích thước nhỏ hơn vì khi bung ra nó sẽ bị nhòe hình. Tốt nhất nên để hình ở định dạng .jpg </strong></em><br />
      
      <br />
       <br />
    </td>
  </tr>
  <tr>
    <td height="203" colspan="2" align="center" valign="top">
   <?php   
   include('db.php');
   $id=$_REQUEST["id"];
   $result=mysql_query("SELECT * FROM ma_sanpham where id like '$id' ");

	$row_dulieu_sua		=	mysql_fetch_array($result);
		$tieude					=	$row_dulieu_sua['tieude'];
		$tieude_en					=	$row_dulieu_sua['tieude_en'];
		$tieude_nhat					=	$row_dulieu_sua['tieude_nhat'];
		$tieude_china				=	$row_dulieu_sua['tieude_china'];
		$tieude_han					=	$row_dulieu_sua['tieude_han'];
		$mota					=	$row_dulieu_sua['mota'];
		$mota_en					=	$row_dulieu_sua['mota_en'];
		$trangchu					=	$row_dulieu_sua['trangchu'];
		$trangthai					=	$row_dulieu_sua['trangthai'];
		$khuyenmai					=	$row_dulieu_sua['khuyenmai'];
		$trangthai_en					=	$row_dulieu_sua['trangthai_en'];
		$masanpham					=	$row_dulieu_sua['masanpham'];
		$hinhanh					=	$row_dulieu_sua['hinhanh'];
		$mota_china					=	$row_dulieu_sua['mota_china'];
		$mota_han					=	$row_dulieu_sua['mota_han'];
		$mota_nhat					=	$row_dulieu_sua['mota_nhat'];
		
		$trangthai					=	$row_dulieu_sua['trangthai'];
		$trangthai_en					=	$row_dulieu_sua['trangthai_en'];
		$trangthai_china					=	$row_dulieu_sua['trangthai_china'];
		$trangthai_han					=	$row_dulieu_sua['trangthai_han'];
		$trangthai_nhat					=	$row_dulieu_sua['trangthai_nhat'];
		
		
		$noidung					=	$row_dulieu_sua['noidung'];
		$noidung=str_replace('"','\"',$noidung);
	    $noidung=str_replace("\n","",$noidung);
	    $noidung=str_replace("\r","",$noidung);
	    $noidung=str_replace("\t","",$noidung);
		
	    $noidung_en					=	$row_dulieu_sua['noidung_en'];
		$noidung_en=str_replace('"','\"',$noidung_en);
	    $noidung_en=str_replace("\n","",$noidung_en);
	    $noidung_en=str_replace("\r","",$noidung_en);
	    $noidung_en=str_replace("\t","",$noidung_en);
		
			$noidung_china					=	$row_dulieu_sua['noidung_china'];
		$noidung_china=str_replace('"','\"',$noidung_china);
	    $noidung_china=str_replace("\n","",$noidung_china);
	    $noidung_china=str_replace("\r","",$noidung_china);
	    $noidung_china=str_replace("\t","",$noidung_china);
		
		$noidung_han					=	$row_dulieu_sua['noidung_han'];
		$noidung_han=str_replace('"','\"',$noidung_han);
	    $noidung_han=str_replace("\n","",$noidung_han);
	    $noidung_han=str_replace("\r","",$noidung_han);
	    $noidung_han=str_replace("\t","",$noidung_han);
		
		$noidung_nhat					=	$row_dulieu_sua['noidung_nhat'];
		$noidung_nhat=str_replace('"','\"',$noidung_nhat);
	    $noidung_nhat=str_replace("\n","",$noidung_nhat);
	    $noidung_nhat=str_replace("\r","",$noidung_nhat);
	    $noidung_nhat=str_replace("\t","",$noidung_nhat);
		
		$noidung_nga					=	$row_dulieu_sua['noidung_nga'];
		$noidung_nga=str_replace('"','\"',$noidung_nga);
	    $noidung_nga=str_replace("\n","",$noidung_nga);
	    $noidung_nga=str_replace("\r","",$noidung_nga);
	    $noidung_nga=str_replace("\t","",$noidung_nga);
		
		$noidung_my					=	$row_dulieu_sua['noidung_my'];
		$noidung_my=str_replace('"','\"',$noidung_my);
	    $noidung_my=str_replace("\n","",$noidung_my);
	    $noidung_my=str_replace("\r","",$noidung_my);
	    $noidung_my=str_replace("\t","",$noidung_my);
		
		$noidung_anh					=	$row_dulieu_sua['noidung_anh'];
		$noidung_anh=str_replace('"','\"',$noidung_anh);
	    $noidung_anh=str_replace("\n","",$noidung_anh);
	    $noidung_anh=str_replace("\r","",$noidung_anh);
	    $noidung_anh=str_replace("\t","",$noidung_anh);
		
		$noidung_phap					=	$row_dulieu_sua['noidung_phap'];
		$noidung_phap=str_replace('"','\"',$noidung_phap);
	    $noidung_phap=str_replace("\n","",$noidung_phap);
	    $noidung_phap=str_replace("\r","",$noidung_phap);
	    $noidung_phap=str_replace("\t","",$noidung_phap);
		
		
		?>
   
   <form action='' method='post' enctype='multipart/form-data' name='tt_mh' id='tt_mh'  onsubmit='return checkInput();'>
      <table width='97%' border='1' bordercolor='black' style='border-collapse:collapse'> 
      
       <tr>
        <td>Chọn loại tin tức</td>
        <td>
           <select name="thuocloai">
        <?
	
	$sql=mysql_query("SELECT * FROM loai_ma_sanpham ORDER BY id DESC");       
     while ($row = mysql_fetch_array($sql)) 
     
	{
		   
                                       
    	?>    
        <option value="<?=$row['id']?>"><?php echo $row['thuocloai']?></option>

		<?php
   } 
    ?>
     </select>

        </td>
       </tr>
        <tr>
          <td width="126"><div align="left"><strong>Hình ảnh</strong></div></td>
          <td width="333"><div align="left">
            <label>
              <input name="txt_hinhanh" type="file" id="txt_hinhanh" size="40" />
              <input name="txt_hinhanh_hide" type="hidden" id="txt_hinhanh"  value="<?php echo "$hinhanh";?>" size="40" />
              </label>
            <br />
            <?php echo"<img src='../Hinh CTSP/$hinhanh' width='60' height='50' />";?> </div></td>
        </tr>
           <tr>
          <td><div align="left"><strong>Tên công ty</strong></div></td>
          <td><div align="left">
            <input name="tieude" type="text" id="tieude" value="<?php echo"$tieude";?>" size="70" />
            </div></td>
        </tr>
        
           <tr>
          <td height="34"><div align="left"><strong>Địa chỉ</strong></div></td>
          <td><div align="left">
            <input name="masanpham" type="text" id="tieude" value="<?php echo"$masanpham";?>" size="70" />
            </div></td>
        </tr>
            <tr>
          <td height="34"><div align="left"><strong>Chủ sở hữu</strong></div></td>
          <td><div align="left">
            <input name="trangthai" type="text" id="tieude" value="<?php echo"$trangthai";?>" size="70" />
            </div></td>
        </tr>

      <tr>
          <td height="34"><div align="left"><strong>Mã số thuế</strong></div></td>
          <td><div align="left">
            <input name="tieude_en" type="text" id="tieude" value="<?php echo"$tieude_en";?>" size="70" />
            </div></td>
        </tr>
        
         <tr>
          <td height="34"><div align="left"><strong>Điện thoại</strong></div></td>
          <td><div align="left">
            <input name="tieude_han" type="text" id="tieude" value="<?php echo"$tieude_han";?>" size="70" />
            </div></td>
        </tr>
    
        <tr>
          <td height="34"><div align="left"><strong>Fax</strong></div></td>
          <td><div align="left">
            <input name="tieude_china" type="text" id="trangthai" value="<?php echo"$tieude_china";?>" size="70" />
            </div></td>
        </tr>
         <tr>
          <td><div align="left"><strong>Email</strong></div></td>
          <td><div align="left">
            <input name="tieude_nhat" type="text" id="giaban" value="<?php echo"$tieude_nhat";?>" size="70" />
            </div></td>
        </tr>
           <tr>
          <td><div align="left"><strong>Phương châm</strong></div></td>
          <td><div align="left">
            <label>
              <textarea name="mota_en" cols="70" rows="4" id="masp" maxlength="130"><?php echo"$mota_en";?></textarea>
            </label>
          </div></td>
        </tr>
        
          <tr>
          <td><div align="left"><strong>Webiste</strong></div></td>
          <td><div align="left">
            <input name="trangthai_nhat" type="text" id="giaban" value="<?php echo"$trangthai_nhat";?>" size="70" />
            </div></td>
        </tr>
          <tr>
          <td><div align="left"><strong>Giờ làm việc</strong></div></td>
          <td><div align="left">
            <input name="trangthai_china" type="text" id="giaban" value="<?php echo"$trangthai_china";?>" size="70" />
            </div></td>
        </tr>
          <tr>
          <td><div align="left"><strong>Trình trạng</strong></div></td>
          <td><div align="left">
            <input name="trangthai_han" type="text" id="giaban" value="<?php echo"$trangthai_han";?>" size="70" />
            </div></td>
        </tr>
           <tr>
          <td><div align="left"><strong>Lĩnh vực kinh doanh</strong></div></td>
          <td><div align="left">
            <label>
              <textarea name="mota_nhat" cols="70" rows="4" id="masp" maxlength="330"><?php echo"$mota_nhat";?></textarea>
            </label>
          </div></td>
        </tr>
        
            <!--<tr>
          <td><div align="left"><strong>Mô Tả</strong></div></td>
          <td><div align="left">
            <label>
              <textarea name="mota_china" cols="70" rows="4" id="masp" maxlength="330"><?php echo"$mota_china";?></textarea>
            </label>
          </div></td>
        </tr>-->
        <tr>
          <td><div align="left"><strong>Thành viên</strong></div></td>
          <td><div align="left">
            <label>
              <textarea name="mota_han" cols="70" rows="4" id="masp" maxlength="130"><?php echo"$mota_han";?></textarea>
            </label>
          </div></td>
        </tr>
          <td><div align="left"><strong>Trang chủ</strong></div></td>
          <td align="left"><label>
            <?php
									if($row_dulieu_sua['trangchu']=="1")
									{
										$a_1="selected";
										$a_2="";
									}
									else
									{
										$a_1="";
										$a_2="selected";
									}
								?>
            <select name="trangchu" id="trangchu">
              <option value="1"<?php echo $a_1; ?> >Có </option>
              <option value="2" <?php echo $a_2; ?>>Không</option>
              </select>
            </label></td>
        </tr>
        <tr>
          <td height="26" colspan="2"><div align="left"><strong>Nội Dung </strong><?php xuat_select("luan","suc"); ?></div>            
            <div align="left"></div></td>
          </tr>
        <tr>
          <td colspan="2">
          
          <div id="div_vn_afc">
						
						 <script type="text/javascript">
										var oFCKeditor = new FCKeditor('txt_noidung');
										oFCKeditor.BasePath = "fckeditor/";
										oFCKeditor.Width	= 700 ;
										oFCKeditor.Height	= 300 ;
										oFCKeditor.Value="<?php echo $noidung; ?>";
										oFCKeditor.Config["EnterMode"]		= "br" ;
										oFCKeditor.Create();
										document.getElementById('xEnter').value = "br" ;
										//document.getElementById("noidung").value=jljl;
									</script> 
					</div>
					<div id="div_en_afc" style="display:none">
						
						 <script type="text/javascript">
										var oFCKeditor = new FCKeditor('txt_noidung_en');
										oFCKeditor.BasePath = "fckeditor/";
										oFCKeditor.Width	= 700 ;
										oFCKeditor.Height	= 300 ;
										oFCKeditor.Value="<?php echo $noidung_en; ?>";
										oFCKeditor.Config["EnterMode"]		= "br" ;
										oFCKeditor.Create();
										document.getElementById('xEnter').value = "br" ;
										//document.getElementById("noidung").value=jljl;
									</script>   
				   </div>            
                    	<div id="div_china_afc" style="display:none">
						
						 <script type="text/javascript">
										var oFCKeditor = new FCKeditor('txt_noidung_china');
										oFCKeditor.BasePath = "fckeditor/";
										oFCKeditor.Width	= 700 ;
										oFCKeditor.Height	= 300 ;
										oFCKeditor.Value="<?php echo $noidung_china; ?>";
										oFCKeditor.Config["EnterMode"]		= "br" ;
										oFCKeditor.Create();
										document.getElementById('xEnter').value = "br" ;
										//document.getElementById("noidung").value=jljl;
									</script>   
				   </div>
            		<div id="div_han_afc" style="display:none">
						
						 <script type="text/javascript">
										var oFCKeditor = new FCKeditor('txt_noidung_han');
										oFCKeditor.BasePath = "fckeditor/";
										oFCKeditor.Width	= 700 ;
										oFCKeditor.Height	= 300 ;
										oFCKeditor.Value="<?php echo $noidung_han; ?>";
										oFCKeditor.Config["EnterMode"]		= "br" ;
										oFCKeditor.Create();
										document.getElementById('xEnter').value = "br" ;
										//document.getElementById("noidung").value=jljl;
									</script>   
				   </div>
            	<div id="div_nhat_afc" style="display:none">
						
						 <script type="text/javascript">
										var oFCKeditor = new FCKeditor('txt_noidung_nhat');
										oFCKeditor.BasePath = "fckeditor/";
										oFCKeditor.Width	= 700 ;
										oFCKeditor.Height	= 300 ;
										oFCKeditor.Value="<?php echo $noidung_nhat; ?>";
										oFCKeditor.Config["EnterMode"]		= "br" ;
										oFCKeditor.Create();
										document.getElementById('xEnter').value = "br" ;
										//document.getElementById("noidung").value=jljl;
									</script>   
				   </div>
                   	<div id="div_nga_afc" style="display:none">
						
						 <script type="text/javascript">
										var oFCKeditor = new FCKeditor('txt_noidung_nga');
										oFCKeditor.BasePath = "fckeditor/";
										oFCKeditor.Width	= 700 ;
										oFCKeditor.Height	= 300 ;
										oFCKeditor.Value="<?php echo $noidung_nga; ?>";
										oFCKeditor.Config["EnterMode"]		= "br" ;
										oFCKeditor.Create();
										document.getElementById('xEnter').value = "br" ;
										//document.getElementById("noidung").value=jljl;
									</script>   
				   </div>
                   	<div id="div_my_afc" style="display:none">
						
						 <script type="text/javascript">
										var oFCKeditor = new FCKeditor('txt_noidung_my');
										oFCKeditor.BasePath = "fckeditor/";
										oFCKeditor.Width	= 700 ;
										oFCKeditor.Height	= 300 ;
										oFCKeditor.Value="<?php echo $noidung_my; ?>";
										oFCKeditor.Config["EnterMode"]		= "br" ;
										oFCKeditor.Create();
										document.getElementById('xEnter').value = "br" ;
										//document.getElementById("noidung").value=jljl;
									</script>   
				   </div>
                   	<div id="div_anh_afc" style="display:none">
						
						 <script type="text/javascript">
										var oFCKeditor = new FCKeditor('txt_noidung_anh');
										oFCKeditor.BasePath = "fckeditor/";
										oFCKeditor.Width	= 700 ;
										oFCKeditor.Height	= 300 ;
										oFCKeditor.Value="<?php echo $noidung_anh; ?>";
										oFCKeditor.Config["EnterMode"]		= "br" ;
										oFCKeditor.Create();
										document.getElementById('xEnter').value = "br" ;
										//document.getElementById("noidung").value=jljl;
									</script>   
				   </div>
                   	<div id="div_phap_afc" style="display:none">
						
						 <script type="text/javascript">
										var oFCKeditor = new FCKeditor('txt_noidung_phap');
										oFCKeditor.BasePath = "fckeditor/";
										oFCKeditor.Width	= 700 ;
										oFCKeditor.Height	= 300 ;
										oFCKeditor.Value="<?php echo $noidung_phap; ?>";
										oFCKeditor.Config["EnterMode"]		= "br" ;
										oFCKeditor.Create();
										document.getElementById('xEnter').value = "br" ;
										//document.getElementById("noidung").value=jljl;
									</script>   
				   </div>
                    </td>
          </tr>
          
          <td height="28"><div align="center"></div></td>
          <td>
            <div align="left">
              <input name="luu"  style="width:100px; color:#FF0000"type="submit" id="luu" value="Lưu Lại" />
            </div></td>
        </tr>
      </table>
    </form></td>
  </tr>
</table>
</body>
</html>
